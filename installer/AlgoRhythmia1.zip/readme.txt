Program: AlgoRhythmia
Version: 1
Operating System:  Windows
Release Date: 1/22/2006
Author:  Xangis
License:  Totally free
Download Location:  www.xangis.com
Installation:  Unzip anywhere convenient.
Use:  Please see "AlgoRhythmia 1 Manual.pdf" for instructions.